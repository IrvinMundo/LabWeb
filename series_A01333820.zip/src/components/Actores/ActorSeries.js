import React, { Component } from 'react';
import './../../css/Actores.css';
import axios from 'axios';

const series = null;
class ActorSeries extends Component{
  constructor(props){
    super(props);
    this.state = { series };
  }
  componentWillMount(){
    axios.get("http://api.tvmaze.com/people/" + this.props.id + "/castcredits?embed=show")
      .then(res => {
        this.setState( { series: res.data } );
      }
    )
  }
  render() {
    const { series } = this.state
    if(undefined !== series && series !== null && this.series !== null){
      return (
      <div>
        <h2>Véalo también en</h2>
        <ul >
          {series.map((serie,i) =>
            <li>{serie._embedded.show.premiered ? serie._embedded.show.premiered.substr(0, 4) : 'S/A'} - {serie._embedded.show.name}</li>
          )}
        </ul>
      </div>
      );
    }else{
      return null;
    }
  }
}
export default ActorSeries;
