import React, { Component } from 'react';
import './../../css/Actores.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import axios from 'axios';
import ActorSeries from './ActorSeries'

const datos = null;
let nombre;
class ActorDetalle extends Component{
  constructor(props){
    super(props);
    this.state = { datos };
  }
  componentWillMount(){
    const programas = JSON.parse(localStorage.getItem('datos'));
    for(let i = 0; i < programas.length; i++){
      if(programas[i].id === this.props.match.params.serieId){
        nombre = programas[i].name;
      }
    }
    console.log(this.props.match.params.id)
    axios.get("http://api.tvmaze.com/people/"+ this.props.match.params.id )
      .then(res => {
        this.setState( { datos:res.data } );
      }
    )
  }
  render() {
    const { datos } = this.state
    if(undefined !== datos && datos !== null && this.series !== null){
    return (
      <div>
        <div id="headA">
          <Link to={'/'}><p>Serie</p></Link>
          <h3>{datos.name} / {nombre}</h3>
        </div>
        <div id="actorDiv">
          <div id="infoActor">
            <div className="imagen">
              <img src={datos.image ? datos.image.medium : 'https://cdn.sofifa.org/player.png'} />
            </div>
            <div className="info">
              <h2>{datos.name}</h2>
              <p>{datos.gender}</p>
              <p>{datos.birthday}</p>
              <p>{datos.country ? datos.country.name : 'No Disponible'}</p>
            </div>
          </div>
          <div id="seriesActor">
            <ActorSeries id = {this.props.match.params.id}  />
          </div>
        </div>
      </div>
    );
  }else{
    return null;
  }
  }
}
export default ActorDetalle;
