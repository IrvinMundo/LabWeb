import React, { Component } from 'react';
import './../../css/Actores.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

class Actor extends Component{
	render() {
		return(
			<li>
			  <span className="im">
			    <img alt={this.props.person.name} src={this.props.character.image ? this.props.character.image.medium : "https://cdn.sofifa.org/player.png"} />
			  </span>
		    <span className="nombre">
					<Link to={`/serie/${this.props.sId}/actor/${this.props.person.id}`}>{ this.props.person.name }</Link>
				</span>
		    <span className="personaje">{ this.props.character.name}</span>
			</li>
		)
	}
}


export default Actor;
