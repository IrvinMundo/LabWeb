import React from 'react';
import './../../css/FormAgregar.css';

const FormAgregar = ({ onNewSerie = f => f}) => {
    let _nombre, _id;
    const submit = e => {
        console.log("submit");
        e.preventDefault();
        onNewSerie(_id.value, _nombre.value);
        _nombre.value = '';
        _id.value = '';
    }

    return ( <form onSubmit ={submit} >
        <h3>¿Desea Agregar Alguna Serie a La Lista?</h3>
        <input ref={input => _nombre = input} type="text" placeholder="Nombre" required />
        <input ref={input => _id = input} type="text" placeholder="id" required />
        <button> Agregar </ button>
    </form> );
};

export default FormAgregar;
