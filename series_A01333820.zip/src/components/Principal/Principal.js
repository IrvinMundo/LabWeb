import React, { Component } from 'react';
import '../../css/App.css';
import './../../css/Principal.css';
import FormAgregar from './FormAgregar'
import Series from '../Series/Series'

const series = [];

class Principal extends Component {

  constructor( props ){
    super( props )
    this.state = { series }
    this.addSerie = this.addSerie.bind(this)
    this.deleteSerie = this.deleteSerie.bind(this)
  }

  componentWillMount(){
     const series = JSON.parse(localStorage.getItem('datos'));
     this.setState({series})
  }

  deleteSerie(id){
    const series = this.state.series;
    const nuevas = series.filter((a) => {
      return a.id !== id
    });
    localStorage.setItem('datos', JSON.stringify(nuevas));
    this.setState({series: nuevas})
  }

  addSerie(id, name) {
    let estadoActual;
    if(this.state.series === null){
      estadoActual = [];
    }else{
      estadoActual = [...this.state.series];
    }

    let estadoSiguiente = [];

    let indice = 0;
    for(let i = 0; i < estadoActual.length; i++){
      if(estadoActual[i].id === id){
        indice = 1;
      }
      estadoActual[i] = {id:estadoActual[i].id, name: estadoActual[i].name};
    }

    if(indice === 0 && isNaN(id) === false){
      let series;
      if(this.state.series === null){
        series = [{id, name}]
      }else{
        series = [
          ...this.state.series,
          {id, name}
        ]
      }
      estadoSiguiente = [...estadoSiguiente,{id, name}]
      localStorage.setItem('datos', JSON.stringify(series));
      this.setState({series})
      
      document.getElementById("mensaje").style.visibility = "visible"
      setTimeout(function() {
        document.getElementById("mensaje").style.visibility = 'hidden';
      }, 2000);
    }else{
      console.log("Ese ID Ya Fue Utilizado")
    }
  }

  render() {
      const { series } = this.state
      return (
        <div className="App">
          <div className="busca">
            <FormAgregar onNewSerie={this.addSerie} />
          </div>
          <div className="listas">
            <div className="titulo">
              <h2>Mis Series</h2>
              <p id="mensaje">La Serie Ha Sido Agregada Correctamente</p>
            </div>
            <Series series={series} onDeleteSerie={this.deleteSerie}  />
          </div>
        </div>
      );
    }
}
export default Principal;
