import React, { Component } from 'react';
import axios from 'axios';
import Actor from '../Actores/Actor';
import './../../css/Series.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";

const actores = [];
class SerieDetalle extends Component{
  constructor(props){
    super(props);
    this.state = { actores };
  }
  componentWillMount(){
    axios.get("http://api.tvmaze.com/shows/"+ this.props.id +"/cast")
      .then(res => {
        this.setState( { actores:res.data } );
      }
    )
  }
  eliminar = e => {
			e.preventDefault();
			this.props.borrar(this.props.id);
	}
  render() {
    const { actores } = this.state
    if(actores.length !== 0){
      return (
        <li className="serieLista" id={this.props.id}>
          <span className="eliminar">
            <button onClick={this.eliminar}> X </ button>
          </span>
          <p className="nombre">
            <Link to={`/serie/${this.props.id}`}>{this.props.name}</Link>
          </p>
          <span className="id">{this.props.id}</span>
          <span className="listaActores">
            <ul >
              {actores.map((actor,i) =>
                <Actor key={i} {...actor} sId = {this.props.id}/>
              )}
            </ul>
          </span>
        </li>
      );
    }else{
      return(
        <li className="listaVacia">
          <span className="eliminar">
            <button onClick={this.eliminar}> X </ button>
          </span>
          <p className="nombre">{this.props.name}<span className="id">{this.props.id}</span></p>
          <p className="noHayActores">No Hay Actores</p>
        </li>
      );

    }

  }
}
export default SerieDetalle;
