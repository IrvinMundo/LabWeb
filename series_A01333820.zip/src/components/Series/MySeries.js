import React, { Component } from 'react';
import './../../css/Series.css';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import axios from 'axios';
import Actor from '../Actores/Actor'

const actores = [];
let nombre;

class MySeries extends Component{
  constructor(props){
    super(props);
    this.state = { actores };
  }
  componentWillMount(){
    const series = JSON.parse(localStorage.getItem('datos'));
    for(let i = 0; i < series.length; i++){
      if(series[i].id === this.props.match.params.id){
        nombre = series[i].name;
      }
    }
    axios.get("http://api.tvmaze.com/shows/"+ this.props.match.params.id +"/cast")
      .then(res => {
        this.setState( { actores:res.data } );
      }
    )
  }
  render() {
    const { actores } = this.state
    return (
      <div>
        <div id="headS">
          <Link to={'/'}><p>Al Menu</p></Link>
          <h2>{nombre}</h2>
        </div>
        <span className="listaSecundaria">
          <ul>
          {actores.map((actor,i) =>
            <Actor key={i} {...actor}/>
          )}
          </ul>
        </span>
      </div>
    );
  }
}
export default MySeries;
