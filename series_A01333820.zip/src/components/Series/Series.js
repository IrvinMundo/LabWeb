import React from 'react';
import './../../css/Series.css';
import SerieDetalle from './SerieDetalle';

const Series = (props) =>{

  return(
    <ul className="listaS">
      {props.series ? props.series.map((serie,i) =>
      	<SerieDetalle key={serie.id} {...serie} borrar = {props.onDeleteSerie} />
      ) : null}
    </ul>
  )
}

export default Series;
