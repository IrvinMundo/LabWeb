import React, { Component } from 'react';
import './css/App.css';
import Principal from './components/Principal/Principal'
import MySeries from './components/Series/MySeries'
import ActorDetalle from './components/Actores/ActorDetalle'
import { BrowserRouter, Route } from 'react-router-dom'
class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className = "main">
          <Route exact path = "/" component = {Principal} />
          <Route exact path = "/serie/:id" component = {MySeries} />
          <Route exact path = "/serie/:serieId/actor/:id" component = {ActorDetalle} />
        </div>
      </BrowserRouter>
    );
  }
}
export default App;
